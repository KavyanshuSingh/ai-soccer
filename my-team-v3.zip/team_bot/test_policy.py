#!/usr/bin/env python3
"""
Test the policy by having it choose an action
"""

import sys
from pathlib import Path

# Add the directories to path
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
sys.path.append(str(Path(__file__).parent.parent.parent))

from policy import Policy

def test_policy():
    """Test the policy with a simple observation"""

    # Create a simple observation
    observation = {
        "player_id": "player_1",
        "opponent_id": "player_2",
        "state": {
            "players": {
                "player_1": {"x": 50.0, "y": 20.0},
                "player_2": {"x": 50.0, "y": 120.0}
            },
            "ball": {
                "possession": "player_1",
                "position": [50.0, 20.0],
                "status": "possessed",
                "possession_steps": 0
            },
            "field": {
                "width": 100.0,
                "height": 140.0,
                "goal_width": 36.0
            }
        },
        "attack_direction": "UP"  # Player 1 attacks upward
    }

    # Create policy instance
    policy = Policy()

    # Get action from policy
    action = policy.choose_action(observation)
    print(f"Chosen action: {action}")

if __name__ == "__main__":
    test_policy()