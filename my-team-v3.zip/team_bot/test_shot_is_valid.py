#!/usr/bin/env python3
"""
Test the shot_is_valid function
"""

import sys
from pathlib import Path

# Add the directories to path
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
sys.path.append(str(Path(__file__).parent.parent.parent))

from policy import shot_is_valid

def test_shot_is_valid():
    """Test the shot_is_valid function with a simple observation"""

    # Create a simple observation where we have possession and are near the opponent goal
    observation = {
        "player_id": "player_1",
        "opponent_id": "player_2",
        "state": {
            "players": {
                "player_1": {"x": 50.0, "y": 20.0},  # Our player near bottom
                "player_2": {"x": 50.0, "y": 120.0}   # Opponent near top
            },
            "ball": {
                "possession": "player_1",  # We have possession
                "position": [50.0, 20.0],  # Ball with our player
                "status": "possessed"
            },
            "field": {
                "width": 100.0,
                "height": 140.0,
                "goal_width": 36.0
            }
        }
    }

    # Test a shot that should be valid - straight up the middle with power 3
    # From y=20 to y=140 (top goal) is 120 units, power 3 gives 96 units distance
    # This might not be enough to reach, but let's test
    result = shot_is_valid(observation, "UP", 3)
    print(f"Shot UP with power 3 from (50,20): {result}")

    # Test with power 2 (64 units) - definitely not enough
    result = shot_is_valid(observation, "UP", 2)
    print(f"Shot UP with power 2 from (50,20): {result}")

    # Test a shot that should NOT be valid - shooting into our own goal
    result = shot_is_valid(observation, "DOWN", 3)
    print(f"Shot DOWN with power 3 from (50,20): {result}")

    # Test when we don't have possession
    observation_no_possession = observation.copy()
    observation_no_possession["state"]["ball"]["possession"] = "player_2"
    result = shot_is_valid(observation_no_possession, "UP", 3)
    print(f"Shot UP with power 3 (no possession): {result}")

if __name__ == "__main__":
    test_shot_is_valid()